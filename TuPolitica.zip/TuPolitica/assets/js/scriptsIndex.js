
jQuery(document).ready(function() {
	
    /*
        Fullscreen background
    */
    $.backstretch([
                    "assets/img/bg.jpg"
	             ],);
    

    
    
});
